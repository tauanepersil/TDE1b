﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TDE.Models;

namespace TDE.Controller
{
    public class ProdutoController : ControllerBase
    {
        private IList<Produtos> listaProduto;
        public ProdutoController()
        {
            listaProduto = new List<Produtos>();

            listaProduto.Add(new Produtos()
            {
                Codigo = "01",
                Nome = "Iphone 8",
                Descricao = "Aparelho celular",
                PrecoVenda = 2300,
                PrecoCusto = 2000,
                DataCadastro = new DateTime(2021, 10, 3),
                Ativo = "",
                Estoque = 10,
                Imagem = "iphone8.png",
                Dimensao = 67.9,
                Categoria = "Smartphone"

            });

            [HttpGet]

        }
    }
}
