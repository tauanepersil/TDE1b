﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TDE.Models
{
    public class Produtos
    {
        public string Codigo { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public float PrecoVenda { get; set; }
        public float PrecoCusto { get; set; }
        public DateTime DataCadastro { get; set; }
        public string Ativo { get; set; }
        public int Estoque { get; set; }
        public string Imagem { get; set; }
        public float Dimensao { get; set; }
        public string Categoria { get; set; }
    }
}
